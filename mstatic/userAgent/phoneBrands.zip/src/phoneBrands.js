const uaall = navigator.userAgent.toLowerCase();
const ua = uaall.split("(")[1].split(")")[0];

let brand = {
	pb:'',
	url:''
};
const phone = [{
		re:/IPHONE/gi,
		url:''
	},{
		re:/huawei/gi,
		url:''
	},{
		re:/mi/gi,
		url:''
	},{
		re:/vivo/gi,
		url:''
	},{
		re:/OPPO/gi,
		url:''
	},{
		re:/samsung/gi,
		url:''
	},{
		re:/SONY/gi,
		url:''
	},{
		re:/Nokia/gi,
		url:''
	},{
		re:/HTC/gi,
		url:''
	},{
		re:/ZTE/gi,
		url:''
	},{
		re:/Lenovo/gi,
		url:''
	},{
		re:/ZUK/gi,
		url:''
	},{
		re:/meizu/gi,
		url:''
}];
	
const P_B = {
	getBrand(){
			if(uaall.match(/MicroMessenger/i)=="micromessenger"){
					brand.pb = "weixin";
					brand.url = '';
			}else if(uaall.match(/QQ/i) == "qq"){
					brand.pb = "qq";
					brand.url = '';
			}else if(phone[0].re.test(ua)){
					brand.pb = "iPhone";
					brand.url = phone[0].url;
			} else if (phone[1].re.test(ua)) {
					brand.pb = "HUAWEI";
					brand.url = phone[1].url;
			} else if (phone[2].re.test(ua)) {
					brand.pb = "xiaomi";
					brand.url = phone[2].url;
			} else if (phone[3].re.test(ua)) {
					brand.pb = "vivo";
					brand.url = phone[3].url;
			} else if (phone[4].re.test(ua)) {
					brand.pb = "OPPO";
					brand.url = phone[4].url;
			} else if (phone[5].re.test(ua)) {
					brand.pb = "SAMSUNG";
					brand.url = phone[5].url;
			} else if (phone[6].re.test(ua)) {
					brand.pb = "SONY";
					brand.url = phone[6].url;
			} else if (phone[7].re.test(ua)) {
					brand.pb = "Nokia";
					brand.url = phone[7].url;
			} else if (phone[8].re.test(ua)) {
					brand.pb = "HTC";
					brand.url = phone[8].url;
			} else if (phone[9].re.test(ua)) {
					brand.pb = "ZTE";
					brand.url = phone[9].url;
			} else if (phone[10].re.test(ua) || phone[11].re.test(ua)) {
					brand.pb = "Lenovo";
					brand.url = phone[10].url;
			} else if (phone[12].re.test(ua)) {
					brand.pb = "meizu";
					brand.url = phone[12].url;
			} else {
					brand.pb = "Android";
					brand.url = '';
			}
			return brand;
	},
	getUserAge(){
		return uaall;
	}
}
export default P_B;