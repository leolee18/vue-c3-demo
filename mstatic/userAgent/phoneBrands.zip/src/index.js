import PB from './phoneBrands.js';

let mIphone = PB.getBrand();
let mUAStr = PB.getUserAge();

let eleSJ = document.getElementById('eleSJ');
let eleAU = document.getElementById('eleAU');

eleSJ.innerHTML = JSON.stringify(mIphone);
eleAU.innerHTML = mUAStr;
console.log(mUAStr);
console.log(JSON.stringify(mIphone));