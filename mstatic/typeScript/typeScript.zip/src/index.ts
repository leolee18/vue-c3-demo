import {mFun} from './ts/type.ts';
import Car from './ts/mcla.ts';

const hello:string = "Helo world";
console.log(hello)

mFun();


//类
// 创建一个对象
var obj = new Car("XXSY1")
// 访问字段
console.log("读取发动机型号 :  "+obj.engine)  
// 访问方法
obj.disp();


