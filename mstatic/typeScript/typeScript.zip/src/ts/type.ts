

function mFun(){
	//Any 类型
	let x:any = 1;
	x = 'I am who I am';
	x = false;
	
	//定义存储各种类型数据的数组时
	let arrayList:any[] = [1,false,'fine'];
	arrayList[1] = 100;
	
	//变量声明
	var uname:string = "Runoob"; 
	var score1:number = 50;
	var score2:number = 42.50
	var sum = score1 + score2 
	console.log("名字: "+uname) 
	console.log("第一个科目成绩: "+score1) 
	console.log("第二个科目成绩: "+score2) 
	console.log("总成绩: "+sum)
	
	//类型断言
	var str = '1' 
	var str2:number = <number> <any> str   //str、str2 是 string 类型
	console.log(str2)
	
	//变量作用域
	var global_num = 12          // 全局变量
	class Numbers { 
		 num_val = 13;             // 类变量
		 static sval = 10;         // 静态变量
		 
		 storeNum():void { 
				var local_num = 14;    // 局部变量
		 } 
	} 
	console.log("全局变量为: "+global_num)  
	console.log(Numbers.sval)   // 静态变量
	var obj = new Numbers(); 
	console.log("类变量: "+obj.num_val)
	
	//条件语句
	var num = 12;
	if (num % 2 == 0) {
			console.log("偶数");
	}else {
			console.log("奇数");
	}
	
	//switch
	var grade:string = "A"; 
	switch(grade) { 
			case "A": { 
					console.log("优"); 
					break; 
			} 
			case "B": { 
					console.log("良"); 
					break; 
			} 
			case "C": {
					console.log("及格"); 
					break;    
			} 
			case "D": { 
					console.log("不及格"); 
					break; 
			}  
			default: { 
					console.log("非法输入"); 
					break;              
			} 
	}
	
	//函数定义
	function test():string {   
			// 函数定义
			console.log("调用函数") ;
			return 'aaa';
	}
	test();
	
	//联合类型
	var val:string|number 
	val = 12 
	console.log("数字为 "+ val) 
	val = "Runoob" 
	console.log("字符串为 " + val)
	
	
	//接口
	interface IPerson { 
			firstName:string, 
			lastName:string, 
			sayHi: ()=>string 
	} 
	 
	var customer:IPerson = { 
			firstName:"Tom",
			lastName:"Hanks", 
			sayHi: ():string =>{return "Hi there"} 
	} 
	 
	console.log("Customer 对象 ") 
	console.log(customer.firstName) 
	console.log(customer.lastName) 
	console.log(customer.sayHi())  
	 
	var employee:IPerson = { 
			firstName:"Jim",
			lastName:"Blakes", 
			sayHi: ():string =>{return "Hello!!!"} 
	} 
	 
	console.log("Employee  对象 ") 
	console.log(employee.firstName) 
	console.log(employee.lastName)
}

export {mFun};