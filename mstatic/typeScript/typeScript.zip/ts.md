#1. 创建工程
```
mkdir ts-webpack 
```
#2. 安装
```
npm install --save-dev webpack webpack-cli
npm install --save-dev typescript ts-loader
```
#3. 创建tsconfig.json
```
{ 
	"compilerOptions": { 
		"outDir": "./dist/", 
		"sourceMap": true,
		"noImplicitAny": true, 
		"module": "commonjs", 
		"target": "es5", 
		"jsx": "react", 
		"allowJs": true 
	} 
}

```
#4.创建webpack.config.js
```
module: { 
	rules: [ { 
			test: /\.tsx?$/, 
			use: 'ts-loader', 
			exclude: /node_modules/ 
			} ] 
}, 
resolve: { 
	extensions: [ '.tsx', '.ts', '.js' ] 
}


```
