const c={
    init(){
        console.log("ccccc")
    }
}
export default c;