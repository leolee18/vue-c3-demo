<template>
	<div>
		<h1>Hello World!</h1>
		<div>postcss</div>
	</div>
</template>

<script>
  export default {
    name: 'App'
  }
</script>

<style>
  html, body {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    font-size: 16px;
  }
	div{
		display: flex;
		background-color: blue;
		font-size: 12px;
	}
</style>
